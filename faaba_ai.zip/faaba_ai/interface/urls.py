from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('generateur_soustitre/', views.subtitles, name='subtitles'),
    path('upload/', views.generate_subtitles, name='generate_subtitles'),
]