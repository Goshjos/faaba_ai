// 
// glightbox.js
// 

var lightbox = GLightbox({ selector: ".glightbox", title: !1 });
