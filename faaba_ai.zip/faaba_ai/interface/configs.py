from transformers import GPT2Tokenizer, GPT2LMHeadModel, Wav2Vec2ForCTC, Wav2Vec2Tokenizer

wav2vec_tokenizer = Wav2Vec2Tokenizer.from_pretrained("facebook/wav2vec2-base-960h")
gpt2_tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
wav2vec_model = Wav2Vec2ForCTC.from_pretrained("facebook/wav2vec2-base-960h")
gpt2_model = GPT2LMHeadModel.from_pretrained("gpt2")