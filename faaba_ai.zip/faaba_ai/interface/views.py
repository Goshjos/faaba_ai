from django.shortcuts import render
from django.http import HttpResponse
import librosa
import logging
from moviepy.editor import VideoFileClip
from google.cloud import speech
from googletrans import Translator
import os

# Configuration du logger
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def home(request):
    return render(request, 'welcome.html')

def subtitles(request):
    return render(request, 'subtitles.html')

def preprocess_video_to_audio(video_file):
    try:
        video_path = video_file.temporary_file_path()
        logger.debug(f"Chemin du fichier vidéo : {video_path}")
        video_clip = VideoFileClip(video_path)
        audio = video_clip.audio
        audio_file_path = "audio.wav"
        audio.write_audiofile(audio_file_path)
        return audio_file_path
    except Exception as e:
        logger.error(f"Erreur lors de la conversion vidéo en audio : {e}")
        return None

def generate_transcription(audio_file_path):
    try:
        # Chemin vers le fichier de clé JSON
        credentials_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'keys', 'galvanized-opus-423515-v3-a9a1b41e1b5c.json')

        # Initialiser le client Google Cloud Speech-to-Text avec les credentials
        client = speech.SpeechClient.from_service_account_file(credentials_path)

        with open(audio_file_path, "rb") as audio_file:
            content = audio_file.read()

        audio = speech.RecognitionAudio(content=content)
        config = speech.RecognitionConfig(
            encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
            sample_rate_hertz=16000,
            language_code="fr-FR",
        )

        response = client.recognize(config=config, audio=audio)
        transcription = ""
        for result in response.results:
            transcription += result.alternatives[0].transcript + " "

        return transcription.strip()
    except Exception as e:
        logger.error(f"Erreur lors de la transcription de l'audio : {e}")
        return ""

def translate_text(text, source_language, target_language):
    try:
        translator = Translator()
        translated_text = translator.translate(text, src=source_language, dest=target_language).text
        return translated_text
    except Exception as e:
        logger.error(f"Erreur lors de la traduction du texte : {e}")
        return text

def generate_translated_subtitles(transcriptions, target_language):
    translated_subtitles = []
    for transcription in transcriptions:
        translated_subtitle = translate_text(transcription, source_language="fr", target_language=target_language)
        translated_subtitles.append(translated_subtitle)
    return translated_subtitles

def generate_subtitles(request):
    if request.method == 'POST':
        video_file = request.FILES.get('video')
        if not video_file:
            return HttpResponse("No video file provided", status=400)

        audio_file_path = preprocess_video_to_audio(video_file)
        if not audio_file_path:
            return HttpResponse("Error processing video file", status=500)

        transcription = generate_transcription(audio_file_path)
        if not transcription:
            return HttpResponse("Error generating transcription", status=500)

        target_language = request.POST.get('language')

        if target_language == 'original':
            translated_subtitles = [transcription]
        else:
            if target_language not in ['fr', 'en', 'es', 'de', 'bariba', 'dendi', 'fongbe', 'yoruba']:
                return HttpResponse("Invalid target language", status=400)
            translated_subtitles = generate_translated_subtitles([transcription], target_language)

        return render(request, 'subtitles.html', {'subtitles': translated_subtitles})
    return render(request, 'upload_video.html')
